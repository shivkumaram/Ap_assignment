import org.w3c.dom.ls.LSOutput;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Scanner;

class Customer extends Product{
    public ArrayList<Product> cart=new ArrayList<>();
    private ArrayList<Deals> deals = new ArrayList<>();

    public ArrayList<Deals> getDeals() {
        return deals;
    }

    public void setDeals(ArrayList<Deals> deals) {
        this.deals = deals;
    }

    private String customer_name;
    private String pass;
    private float amount;

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public Customer(String name, String pass){
        this.customer_name=name;
        this.pass=pass;
        this.amount=1000;
    }

    void getproduct(){
        for(int i = 0; i< cart.size(); i++){
            System.out.println("The product id is: "+cart.get(i).getProduct_id());
            System.out.println("The product name is: "+cart.get(i).getProduct_name());
            System.out.println("The product details are : "+cart.get(i).getOther_details());
        }
    }
    public String getCustomer_name() {
        return customer_name;
    }

    public String getPass() {
        return pass;
    }

    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public  void Signup(){

    }
    public  void Login(){

    }
    public  void Upgrade_status(){

    }
    public  void Explore_Product_Catalog(){

    }
    public  void Add_product_to_cart(){

    }
    public  void Payment(){

    }

}

//********************************************************************
class admin {
    private ArrayList<Category> catg = new ArrayList<>();
    private ArrayList<Customer> custom = new ArrayList<>();

    private ArrayList<Deals> deals = new ArrayList<>();
    public boolean displaydeals(){
        if(deals.size()==0){
            return true;

        }
        for(int i =0; i < deals.size(); i++){
            System.out.println("Product 1 id is: "+deals.get(i).getProduct1());
            System.out.println("Product 2 id is: "+deals.get(i).getProduct2());
            System.out.println("Combined product cost: "+deals.get(i).getComibedprice());
        }
        return false;
    }

    public void setCatg(ArrayList<Category> catg) {
        this.catg = catg;
    }

    public ArrayList<Customer> getCustom() {
        return custom;
    }

    public void setCustom(ArrayList<Customer> custom) {
        this.custom = custom;
    }

    public ArrayList<Deals> getDeals() {
        return deals;
    }

    public void setDeals(ArrayList<Deals> deals) {
        this.deals = deals;
    }

    public int getPassword() {
        return password;
    }

    private String username;
    private int password;

    public void add_customer(Customer cust) {
        custom.add(cust);
    }
    public boolean check_catg(int catgid) {
        for (Category category : catg) {
            if (catgid == category.getCategory_id()) {
                return true;
            }
        }
        return false;
    }
    public boolean check_customer(String name, String pass) {
        for (int i = 0; i < custom.size(); i++) {
            if (custom.get(i).getCustomer_name().compareTo(name) == 0 && custom.get(i).getPass().compareTo(pass) == 0) {
                return true;
            }
        }
        return false;
    }
    public boolean check_product(int cat_id, int pro_id) {
        for (Category category : catg) {
            for (int j = 0; j < category.get_productList().size(); j++) {
                if (category.get_productList().get(j).getProduct_id() == pro_id)
                    return true;
            }
        }
        return false;
    }
    public String getUsername() {
        return username;
    }

    public int getpassword() {
        return password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(int password) {
        this.password = password;
    }

    public void Enter_as_Admin(String username,int password) {
        this.username=username;
        this.password=password;
    }

    public void Add_Category(Category cat) {
        catg.add(cat);
    }
    public void Delete_category(int  cat ) {
        catg.remove((cat)-1);

    }
    public void Add_Product(int category_id,Product name) {

            this.catg.get(category_id-1).product_add(name);
    }
    public void Delete_product(int category_id,int product_id) {
        this.catg.get(category_id-1).get_productList().remove(product_id-1);
    }
    public void Set_Discount_on_Product(int category_id,int product_id,int elite_dis,int prime_dis,int normal_dis) {
        catg.get(category_id-1).get_productList().get(product_id-1).setElite_dic(elite_dis);
        catg.get(category_id-1).get_productList().get(product_id-1).setElite_dic(prime_dis);
        catg.get(category_id-1).get_productList().get(product_id-1).setElite_dic(normal_dis);

    }

    public void Add_giveaway_deals() {

    }

    public ArrayList<Category> getCatg() {
        return catg;
    }
    public Customer get_customer(String name){
        for(int i=0;i< custom.size();i++){
            if(custom.get(i).getCustomer_name().compareTo(name)==0){
                return custom.get(i);
            }
        }
        return null;

    }
    public Product get_product(int category_id,int product_id){
        return catg.get(category_id).get_productList().get(product_id);

    }

    public void add_deal(Deals deal) {
        this.deals.add(deal);
    }



}
class Product{
    private String product_name;
    private int product_id;

    private String other_details;
    private float price;
    private int elite_dic;
    private int prime_disc;
    private int normal_disc;

    public String getOther_details() {
        return other_details;
    }

    public void setOther_details(String other_details) {
        this.other_details = other_details;
    }

    public int getElite_dic() {
        return elite_dic;
    }

    public void setElite_dic(int elite_dic) {
        this.elite_dic = elite_dic;
    }

    public int getPrime_disc() {
        return prime_disc;
    }

    public void setPrime_disc(int prime_disc) {
        this.prime_disc = prime_disc;
    }

    public int getNormal_disc() {
        return normal_disc;
    }

    public void setNormal_disc(int normal_disc) {
        this.normal_disc = normal_disc;
    }

    public Product(String product_name, int  product_id, String other_details, float price) {
        this.product_name = product_name;
        this.product_id = product_id;
        this.other_details = other_details;
        this.price = price;
    }
    Product(){

    }
    public String getProduct_name() {
        return product_name;
    }

    int getProduct_id() {
        return product_id;
    }
    public float getPrice() {
        return price;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public void setProduct_id(int  product_id) {
        this.product_id = product_id;
    }

    public void setPrice(float price) {
        this.price = price;
    }
    public void print(){
        System.out.println("Product id is: "+ product_id);
        System.out.println("Product name is: "+ product_name);
        System.out.println("Other details: "+ other_details);
        System.out.println("Price: "+ price);


    }
}
class Category{
    public ArrayList<Product> prod=new ArrayList<Product>();
    ArrayList<Product> get_productList(){
        return prod;
    }
    public void product_add(Product product){
        prod.add(product);
    }
    private int category_id;
    private String category_name;

    public int getCategory_id() {
        return category_id;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_id(int category_id) {
        this.category_id = category_id;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }
    public Category(int category_id,String category_name){
        this.category_id=category_id;
        this.category_name=category_name;

    }

}
class Deals{
    private int dealsID;
    private float comibedprice;
    private int product1, product2;
    private float elitePrice, primePrice, normalPrice;
    public int getProduct1() {
        return product1;
    }

    public void setProduct1(int product1) {
        this.product1 = product1;
    }

    public int getProduct2() {
        return product2;
    }
    float getComibedprice(){
        return comibedprice;
    }
    public void setProduct2(int product2) {
        this.product2 = product2;
    }

    public float getElitePrice() {
        return elitePrice;
    }

    public void setElitePrice(float elitePrice) {
        this.elitePrice = elitePrice;
    }

    public float getPrimePrice() {
        return primePrice;
    }

    public void setPrimePrice(float primePrice) {
        this.primePrice = primePrice;
    }

    public float getNormalPrice() {
        return normalPrice;
    }

    public void setNormalPrice(float normalPrice) {
        this.normalPrice = normalPrice;
    }
    public Deals(int dealsID, int product1, int product2, float combinedprice) {
        this.product1 = product1;
        this.product2 = product2;
        this.dealsID = dealsID;
        this.comibedprice = combinedprice;
    }

}

public class Main{
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        int dealNumber = 0;
        System.out.println("WELCOME TO FLIPZON");
        admin adm=new admin();
        boolean exit=false;
        while(!exit){
            fun1();
            int a = sc.nextInt();
            if (a == 1) {
                System.out.println("Dear Admin,");
                System.out.println("Please enter your username and password");
                sc.nextLine();
                String admin_name=sc.nextLine();
                int  admin_password=sc.nextInt();
                adm.Enter_as_Admin("Shivam",2021489);

                System.out.println("Welcome "+adm.getUsername()+"!!!!!");
                boolean exit_1=false;
                    while(!exit_1){
                        if(admin_name.compareTo(adm.getUsername())==0  && admin_password== adm.getpassword()){

                            System.out.println("Please choose any one of the following actions:");
                            fun_admin();
                            int b=sc.nextInt();
                            if (b==1) {
                                System.out.println("Add category ID");
                                int category_id=sc.nextInt();
                                if(!adm.check_catg(category_id)){
                                    System.out.println("Add name of the category");
                                    sc.nextLine();
                                    String name_category= sc.nextLine();
                                    Category cat=new Category(category_id,name_category);
                                    adm.Add_Category(cat);
                                    System.out.println("Add a Product:-");
                                    System.out.println("Product Name:");
                                    String product_name=sc.nextLine();

                                    System.out.println("Product ID:");
                                    String inputString = sc.nextLine();
                                    String[] splitIDs = inputString.split("\\.");
                                    int product_id = Integer.parseInt(splitIDs[1]);
                                    System.out.println("Other details");
                                    String other_detail=sc.nextLine();
                                    sc.nextLine();
                                    System.out.println("Price:");
                                    float price=sc.nextFloat();
                                    Product product=new Product(product_name, product_id, other_detail, price);
                                    adm.Add_Product(category_id,product);

                                }
                                else {
                                    System.out.println("Dear Admin, the category ID is already used!!! Please set a different and a unique category ID");
                                }

                            }
                            else if (b==2) {
                                System.out.println("Enter the category which you want to delete:");
                                int  del=sc.nextInt();
                                if(!adm.check_catg(del)){
                                    adm.Delete_category(del);
                                }
                                else{
                                    System.out.println("product is not available!");
                                }
                            }
                            else if(b==3){
                                System.out.println("Enter category ID");
                                int input_category=sc.nextInt();

                                    System.out.println("Add a Product:-");
                                    System.out.println("Product name:");
                                    sc.nextLine();

                                    String pro_name=sc.nextLine();
                                    System.out.println("Product ID:");
                                    String [] arr=sc.nextLine().split("\\.");
                                    System.out.println("Price:");
                                    float pro_price=sc.nextFloat();
                                    System.out.println("Other details:");
                                    sc.nextLine();
                                    String other_details=sc.nextLine();

                                    if(!(adm.check_product(Integer.parseInt(arr[0]),Integer.parseInt(arr[1])))){
                                        Product product=new Product(pro_name,Integer.parseInt(arr[1]),other_details,pro_price);
                                        adm.Add_Product(input_category,product);
                                    }

                                    else{
                                    System.out.println("Wrong input!");
                                   }
                            }
                            else if (b==4) {
                                System.out.println("Enter the product Id which you want to delete:");
                                String  arr[]=sc.next().split("\\.");
                                if(!adm.check_catg(Integer.parseInt(arr[0])) && !adm.check_product(Integer.parseInt(arr[0]),Integer.parseInt(arr[1]))){
                                    adm.Delete_product(Integer.parseInt(arr[0]),Integer.parseInt(arr[1]));
                                }
                            }
                            else if (b==5) {
                                System.out.println("Dear Admin give the Product ID you want to add discount for");
                                System.out.println("Enter the Product ID :");
                                String  arr[]=sc.next().split("\\.");

                                if((adm.check_catg(Integer.parseInt(arr[0])) && adm.check_product(Integer.parseInt(arr[0]),Integer.parseInt(arr[1])))){
                                    System.out.println("Enter discount for Elite, Prime and Normal customers respectively (in % terms)");
                                    int elite_dis=sc.nextInt();
                                    int prime_disc=sc.nextInt();
                                    int normal_disc=sc.nextInt();
                                    adm.Set_Discount_on_Product(Integer.parseInt(arr[0]),Integer.parseInt(arr[1]),elite_dis,prime_disc,normal_disc);
                                }

                            }
                            else if (b==6) {
                                int p1 = 0, p2 = 0;
                                System.out.println("Dear Admin give the Product IDs you want to combine and giveaway a deal for");
                                System.out.println("Enter the first Product ID :");
                                String arr1[] = sc.next().split("\\.");
                                System.out.println("Enter the second Product ID:");
                                String arr2[] = sc.next().split("\\.");
                                // handle user input verification and invalid input

                                for (int i = 0; i < adm.getCatg().size(); i++) {
                                    for (int j = 0; j < adm.getCatg().get(i).get_productList().size(); j++) {
                                        if (Integer.parseInt(arr1[1]) == adm.getCatg().get(i).get_productList().get(j).getProduct_id()) {
                                            p1 = adm.getCatg().get(i).get_productList().get(j).getProduct_id();
                                        }
                                        if (Integer.parseInt(arr2[1]) == adm.getCatg().get(i).get_productList().get(j).getProduct_id()) {
                                            p2 = adm.getCatg().get(i).get_productList().get(j).getProduct_id();
                                        }
                                    }
                                }

                                System.out.println("Enter the combined price (Should be less than their combined price): ");
                                float normalPrice = sc.nextFloat();
                                Deals deal = new Deals(++dealNumber, p1, p2, normalPrice);
                                adm.add_deal(deal);

                            }
                            else if (b==7) {
                                exit_1=true;
                            }
                            else{
                                System.out.println("Oops! wrong option. Select only above given seven options.");


                            }

                        }
                        else{
                            System.out.println("you are not admin sorry!!");
                            exit_1=true;
                        }

                        }

                        }
            else if (a == 2) {
                for(int i=0;i<adm.getCatg().size(); i++) {
                    for (int j=0; j < adm.getCatg().get(i).get_productList().size(); j++) {
                        System.out.println("Product name: " + adm.getCatg().get(i).get_productList().get(j).getProduct_name());
                        System.out.println("Product ID: " + adm.getCatg().get(i).get_productList().get(j).getProduct_id());
                        System.out.println("Product price: " + adm.getCatg().get(i).get_productList().get(j).getPrice());
                    }
                }

            }
            else if (a == 3) {
                if(adm.displaydeals()){
                    System.out.println("Dear User, there are no deals for now!!! Please check regularly for exciting deals.");
                }
            }
            else if (a == 4) {

                boolean exit_2=false;
                while(!exit_2){
                    fun_customer();
                    int p=sc.nextInt();
                    if(p==1){
                        System.out.println("Enter name");
                        sc.next();
                        String name=sc.nextLine();
                        System.out.println("Enter password");
                        String password=sc.nextLine();
                        Customer custom= new Customer(name,password);
                        adm.add_customer(custom);
                        System.out.println("customer successfully registered!!");

                    }
                    else if(p==2){
                        System.out.println("Enter name");
                        sc.nextLine();
                        String name=sc.nextLine();
                        System.out.println("Enter password");
                        String pasword=sc.nextLine();
                        if(!adm.check_customer(name,pasword)){
                            System.out.println("Welcome"+" "+name);
                            boolean exit_3=false;
                            while(!exit_3){
                                fun_customer2();
                                int q;
                                q=sc.nextInt();
                                if(q==1){
                                    for(int i=0;i<adm.getCatg().size(); i++) {
                                        for (int j=0; i < adm.getCatg().get(i).get_productList().size(); j++) {
                                            System.out.println("Product name: " + adm.getCatg().get(i).get_productList().get(j).getProduct_name());
                                            System.out.println("Product ID: " + adm.getCatg().get(i).get_productList().get(j).getProduct_id());
                                            System.out.println("Product price: " + adm.getCatg().get(i).get_productList().get(j).getPrice());
                                        }
                                    }
                                }
                                else if(q==2){
                                    if(adm.displaydeals()){
                                        System.out.println("Dear User, there are no deals for now!!! Please check regularly for exciting deals.");
                                    }
                                }
                                else if(q==3){
                                    System.out.println("Enter product ID");
                                    String arr[]=sc.next().split("\\.");
                                    if(!adm.check_catg(Integer.parseInt(arr[0])) && !adm.check_product(Integer.parseInt(arr[0]),Integer.parseInt(arr[1]))){
                                        System.out.println("Enter quantity");
                                        int quant=sc.nextInt();
                                        adm.get_customer(name).cart.add(adm.getCatg().get(Integer.parseInt(arr[0])).get_productList().get(Integer.parseInt((arr[1]))));

                                    }
                                }
                                else if(q==4){
                                    System.out.println("enter deal id:");
                                    int deal_id=sc.nextInt();
                                    System.out.println("Enter quantity:");
                                    int qty=sc.nextInt();
                                    adm.get_customer(name).getDeals().add(adm.getDeals().get(deal_id));
                                }
                                else if(q==5){

                                }
                                else if(q==6){
//
                                    System.out.println("Current account balance is Rs"+adm.get_customer(name).getAmount());


                                }
                                else if(q==7){
                                    for(int i=0;i<adm.get_customer(name).cart.size();i++){
                                        adm.get_customer(name).cart.get(i).print();
                                    }

                                }
                                else if(q==8){
                                    adm.get_customer(name).cart.clear();
                                    System.out.println("Cart successfully emptied");

                                }
                                else if(q==9){

                                }
                                else if(q==10){

                                }
                                else if(q==11){
                                    System.out.println("Enter amount to add");
                                    float paisa=sc.nextFloat();
                                    adm.get_customer(name).setAmount(adm.get_customer(name).getAmount()+paisa);

                                }
                                else if(q==12){
                                    exit_3=true;
                                }
                                else{
                                    System.out.println("Wrong input!!!");
                                }
                            }
                        }
                        else{
                            System.out.println("Not signup!!");
                        }
                    }
                   else if(p==3){
                       exit_2=true;
                    }
                }
            }
           else if (a==5) {
                System.out.println("Thank you for using FLIPZONE");
                exit=true;
           }
        }
    }
    static void fun1() {                        //main menu function
        System.out.println("1) Enter as Admin");
        System.out.println("2) Explore the Product Catalog");
        System.out.println("3) Show Available Deals");
        System.out.println("4) Enter as Customer");
        System.out.println("5) Exit the Application");

    }
    static void fun_admin() {            //admin function
        System.out.println(
                "1) Add category\n" +
                "2) Delete category\n" +
                "3) Add Product\n" +
                "4) Delete Product\n" +
                "5) Set Discount on Product\n" +
                "6) Add giveaway deal\n" +
                "7) Back");


    }
    static void fun_customer() {
        System.out.println("1) Sign up\n" +
                "2) Log in\n" +
                "3) Back");
    }
    static void fun_customer2() {
        System.out.println("1) browse products\n" +
                "2) browse deals\n" +
                "3) add a product to cart\n" +
                "4) add products in deal to cart\n" +
                "5) view coupons\n" +
                "6) check account balance\n" +
                "7) view cart\n" +
                "8) empty cart\n" +
                "9) checkout cart\n" +
                "10) upgrade customer status\n" +
                "11) Add amount to wallet\n" +
                "12) back");
    }
}

