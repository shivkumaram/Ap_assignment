import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

class Student{
    private String name;
    private int roll_no;
    private float CGPA;
    private String Branch;
    private String status;

    public ArrayList<Company> getOffered_companies() {
        return offered_companies;
    }

    public void addOffered_companies(Company company) {
        this.offered_companies.add(company);
    }

    private ArrayList<Company> offered_companies=new ArrayList<>();

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    private Company company;

    public String getname() {
        return name;
    }

    public int getRoll_no() {
        return roll_no;
    }


    public float getCGPA() {
        return CGPA;
    }

    public String getBranch() {

        return Branch;
    }

    //constuctor:
    Student(String name,int roll_no,float CGPA,String branch){
        this.name=name;
        this.roll_no=roll_no;
        this.CGPA=CGPA;
        this.Branch=branch;
        this.status="not-applied";
        this.company=null;
    }

    public void Register_for_company(){

    }
    public void Get_All_available_companies(){

    }
    public String getStatus(){
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void Update_CGPA(float CGPA){
        this.CGPA = CGPA;
    }
    public void Accept_offer(Company company){
        this.company=company;
        this.status="placed";
    }
    public void Reject_offer(){

    }


}

class Institute{
    private static Date Open_date_for_student;
    private static Date Close_date_for_student;
    private static Date Open_date_for_company_reg;
    private static Date Close_date_for_company_reg;

    public static void setOpen_date_for_company_reg(Date Open_date_for_company_reg) {
        Institute.Open_date_for_company_reg = Open_date_for_company_reg;
    }

    public static Date getOpen_date_for_company_reg(){
        return Open_date_for_company_reg;
    }
    public static void  setClose_date_for_company_reg (Date Close_date_for_company_reg) {
        Institute.Close_date_for_company_reg = Close_date_for_company_reg;
    }

    public static Date getClose_date_for_company_reg(){
        return Close_date_for_company_reg;
    }

    public static void  setOpen_date_for_student(Date Open_date_for_student) {
        Institute.Open_date_for_student = Open_date_for_student;
    }

    public static Date getOpen_date_for_student() {
        return Open_date_for_student;
    }
    public static void setClose_date_for_student(Date Close_date_for_student ){
        Institute.Close_date_for_student = Close_date_for_student;

    }
    public static Date getClose_date_for_student() {
        return Close_date_for_student;
    }

    static ArrayList<Company> registered_company=new ArrayList<>();
    static ArrayList<Student> registered_student=new ArrayList<>();
    static ArrayList<Student> students_offered=new ArrayList<>();
    public void Open_Student_Registrations(){

    }
    public void Open_Company_Registrations(){

    }
    public void Get_Number_of_Student_Registrations(){

    }
    public void Get_Number_of_Company_Registrations(){

    }
    public void Get_Number_of_Placed_students(){

    }
    public void No_unplaced_placed_students(){

    }
    public void No_Blocked_Students(){

    }
    public void Get_Student_Details(){

    }
    public void Get_Company_Details(){

    }
    public void Get_Average_Package(){

    }
    public void Get_Company_Process_Results(){

    }

}


class Company {
    static ArrayList <Student> comp_reg_stu=new ArrayList<>();
    private String name_of_the_company;
    private String Role_a_company_offers;
    private double Package_offered;
    private float CGPA_criteria;

    public String getName_of_the_company() {
        return name_of_the_company;
    }

    public String getRole_a_company_offers() {
        return Role_a_company_offers;
    }

    public double getPackage_offered() {
        return Package_offered;
    }

    public float getCGPA_criteria() {
        return CGPA_criteria;
    }
    public void Get_Selected_Students(){

    }
    public void Update_Role(String update){
        Role_a_company_offers=update;

    }
    public void Update_Package(double update_package){
        Package_offered=update_package;

    }
    public void Update_CGPA_criteria(float update_cg){
        CGPA_criteria=update_cg;

    }
    Company(String company_name,String role,double pack,float min_CGPA){
        this.name_of_the_company=company_name;
        this.Role_a_company_offers=role;
        this.Package_offered=pack;
        this.CGPA_criteria=min_CGPA;

    }
}


public class Main{
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws ParseException {
        ArrayList<Student> student=new ArrayList<>();
        ArrayList<Company> company=new ArrayList<>();

        int n, k;
        boolean exit = false;
        while (!exit) {
            A_1();
            n = sc.nextInt();
            if (n == 1) {
                boolean goBack1 = false;
                while (!goBack1) {
                    A_2();
                    k = sc.nextInt();
                    if (k == 1) {
                        boolean goBack2 = false;
                        while (!goBack2) {
                            B_1();
                            int p;
                            p = sc.nextInt();
                            if (p == 1) {
                                sc.nextLine();
                                System.out.println("Enter Name: ");
                                String name = sc.nextLine();
                                System.out.println("Enter Roll No: ");
                                int roll_no = sc.nextInt();
                                boolean student_found = false;
                                Student current = new Student("Default", 10, 1, "XXX");
                                for (int i = 0; i < student.size(); i++) {
                                    if (student.get(i).getname().equals(name) && student.get(i).getRoll_no() == roll_no) {
                                        current = student.get(i);
                                        student_found = true;
                                    }
                                }
                                if (student_found) {
                                    System.out.println("Welcome " + current.getname() + "!!");
                                    boolean goBack3 = false;
                                    while (!goBack3) {
                                        C_1();
                                        int z = sc.nextInt();
                                        if (z == 1) {
                                            //date and time
                                            System.out.println(current.getname() + " Registered for the Placement Drive at IIITD!!!!");
                                            System.out.println("Your details are:");
                                            System.out.println("Name: " + current.getname());
                                            System.out.println("Roll no" + current.getRoll_no());
                                            System.out.println("CGPA:" + current.getCGPA());
                                            System.out.println("Branch: " + current.getCGPA());
                                            Institute.registered_student.add(current);
                                        } else if (z == 2) {
                                            String choice = sc.nextLine();
                                            for(int i=0;i<Institute.registered_company.size();i++) {
                                                if (choice.equals(Institute.registered_company.get(i).getName_of_the_company())) {
                                                    Company.comp_reg_stu.add(current);
                                                    if (current.getStatus().equals("offered") && current.getCGPA()>=Institute.registered_company.get(i).getCGPA_criteria()) {
                                                        if (Institute.registered_company.get(i).getPackage_offered() >= 3 * current.getCompany().getPackage_offered()) {
                                                            Institute.students_offered.add(current);
                                                            current.addOffered_companies(Institute.registered_company.get(i));
                                                            current.setStatus("offered");
                                                            System.out.println("Successfully Registered for" + Institute.registered_company.get(i).getRole_a_company_offers() + "Role at" + Institute.registered_company.get(i).getName_of_the_company() + "!!!");
                                                        }
                                                    }
                                                    else if (current.getStatus().equals("unplaced") && current.getCGPA()>=Institute.registered_company.get(i).getCGPA_criteria()) {
                                                        Institute.students_offered.add(current);
                                                        current.addOffered_companies(Institute.registered_company.get(i));
                                                        current.setStatus("offered");
                                                        System.out.println("Successfully Registered for" + Institute.registered_company.get(i).getRole_a_company_offers() + "Role at" + Institute.registered_company.get(i).getName_of_the_company() + "!!!");
                                                    }
                                                    else {
                                                        System.out.println("Sorry, you're not eligible to apply to this company!");
                                                        break;
                                                    }
                                                }
                                            }
                                        } else if (z == 3) {
                                            System.out.println("List of All available companies is as follows:");
                                            System.out.println("Total: " + Institute.registered_company.size());
                                            for (int j = 0; j < Institute.registered_company.size(); j++) {
                                                System.out.println(j + 1 + ") " + "CompanyName: " + Institute.registered_company.get(j).getName_of_the_company());
                                                System.out.println("Company role offering: " + Institute.registered_company.get(j).getRole_a_company_offers());
                                                System.out.println("Company Package: " + Institute.registered_company.get(j).getPackage_offered());
                                                System.out.println("Company CGPA criteria: " + Institute.registered_company.get(j).getCGPA_criteria());

                                            }
                                        } else if (z == 4) {
                                            if (current.getOffered_companies().size() >= 1) {
                                                for (int i = 0; i < current.getOffered_companies().size(); i++) {
                                                    System.out.println("Company: " + current.getOffered_companies().get(i).getName_of_the_company());
                                                    System.out.println("Role: " + current.getOffered_companies().get(i).getRole_a_company_offers());
                                                    System.out.println("Status: " + current.getStatus());
                                                }
                                            }
                                            else {
                                                System.out.println("Your current status: " + current.getStatus());
                                            }
                                        } else if (z == 5) {
                                            System.out.println("Enter new CGPA: ");
                                            float newCGPA = sc.nextFloat();
                                            current.Update_CGPA(newCGPA);
                                            System.out.println("Updated!");

                                        } else if (z == 6) {
                                            if (current.getOffered_companies().size() >= 1) {
                                                for (int i = 0; i < current.getOffered_companies().size(); i++) {
                                                    System.out.println((i+1) + ") Company: " + current.getOffered_companies().get(i).getName_of_the_company());
                                                    System.out.println("Role: " + current.getOffered_companies().get(i).getRole_a_company_offers());
                                                    System.out.println("Status: " + current.getStatus());
                                                }
                                                System.out.println("Enter your choice");
                                                int ch = sc.nextInt();
                                                current.setStatus("placed");
                                                current.setCompany(current.getOffered_companies().get(ch - 1));
                                                System.out.println("You have accepted the offer by " + current.getOffered_companies().get(ch - 1).getName_of_the_company());

                                            }
                                            else {
                                                System.out.println("Sorry, you haven't been offered any role.");
                                            }

                                        } else if (z == 7) {
                                            if (current.getOffered_companies().size() >= 1) {
                                                for (int i = 0; i < current.getOffered_companies().size(); i++) {
                                                    System.out.println((i+1) + ") Company: " + current.getOffered_companies().get(i).getName_of_the_company());
                                                    System.out.println("Role: " + current.getOffered_companies().get(i).getRole_a_company_offers());
                                                    System.out.println("Status: " + current.getStatus());
                                                }
                                                System.out.println("Enter your choice");
                                                int ch = sc.nextInt();
                                                current.setCompany(current.getOffered_companies().get(ch - 1));
                                                System.out.println("You have rejected the offer by " + current.getOffered_companies().get(ch - 1).getName_of_the_company());
                                                if (current.getOffered_companies().size() == 1) {
                                                    current.setStatus("blocked");
                                                }
                                                else {
                                                    current.setStatus("unplaced");
                                                }
                                            }
                                            else {
                                                System.out.println("Sorry, you haven't been offered any role.");
                                            }
                                        } else if (z == 8) {
                                            goBack3 = true;
                                        }
                                    }
                                }
                            } else if (p == 2) {
                                System.out.println("Number of students to add ");
                                int no_of_students;
                                no_of_students = sc.nextInt();
                                sc.nextLine();
                                System.out.println("Please add students Name, Roll No, CGPA, Branch(in order):");
                                for (int i = 0; i < no_of_students; i++) {
                                    System.out.println("Enter name:  ");
                                    String name = sc.nextLine();
                                    System.out.println("Enter Roll no: ");
                                    int roll_no = sc.nextInt();
                                    System.out.println("Enter CGPA: ");
                                    float CGPA = sc.nextFloat();
                                    sc.nextLine();
                                    System.out.println("Enter Branch: ");
                                    String branch = sc.nextLine();
                                    Student stud = new Student(name, roll_no, CGPA, branch);
                                    student.add(stud);
                                    System.out.println("Student added!");
                                }
                            } else if (p == 3) {
                                goBack2 = true;
                            }
                        }
                    } else if (k == 2) {
                        boolean goBack2 = false;
                        while (!goBack2) {
                            B_2();
                            int q;
                            q = sc.nextInt();
                            if (q == 1) {
                                sc.nextLine();
                                System.out.println("Enter company: ");
                                String company_name = sc.nextLine();
                                System.out.println("Enter role: ");
                                String role = sc.nextLine();
                                System.out.println("Enter CTC: ");
                                double pack = sc.nextDouble();
                                System.out.println("Enter CGPA: ");
                                float min_CGPA = sc.nextFloat();
                                Company comp = new Company(company_name, role, pack, min_CGPA);
                                company.add(comp);
                                System.out.println("Company added!");
                            } else if (q == 2) {
                                System.out.println("Choose To enter into mode of Available Companies:-");
                                for (int i = 0; i < company.size(); i++) {
                                    System.out.print(i + 1 + ") ");
                                    System.out.println(company.get(i).getName_of_the_company());
                                }
                                int select = sc.nextInt();
                                Company c1 = company.get(select - 1);
                                boolean goBack3 = false;
                                while (!goBack3) {
                                    System.out.println("Welcome " + c1.getName_of_the_company());
                                    System.out.println("1) Update Role\n" +
                                            "2) Update Package\n" +
                                            "3) Update CGPA criteria\n" +
                                            "4) Register To Institute Drive\n" +
                                            "5) Back");
                                    int t;
                                    t = sc.nextInt();
                                    if (t == 1) {
                                        String update_role;
                                        sc.nextLine();
                                        System.out.println("Enter new role: ");
                                        update_role = sc.nextLine();
                                        c1.Update_Role(update_role);
                                    } else if (t == 2) {
                                        double update_package;
                                        System.out.println("Enter new package: ");
                                        update_package = sc.nextDouble();
                                        c1.Update_Package(update_package);
                                    } else if (t == 3) {
                                        float update_cg;
                                        System.out.println("Enter new CGPA requirement: ");
                                        update_cg = sc.nextFloat();
                                        c1.Update_CGPA_criteria(update_cg);

                                    } else if (t == 4) {
                                        Institute.registered_company.add(c1);
                                        SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy, HH:mm");
                                        Date date = new Date();
                                        System.out.println(dateFormat.format(date));
                                        System.out.println("Company registered!");
                                    } else if (t == 5) {
                                        goBack3 = true;
                                    }

                                }
                            } else if (q == 3) {
                                for(int i=0;i<Institute.registered_company.size();i++){
                                    System.out.println(Institute.registered_company.get(i).getName_of_the_company());
                                }

                            } else if (q == 4) {
                                goBack2 = true;
                            }
                        }
                    } else if (k == 3) {
                        boolean goBack3 = false;
                        while (!goBack3) {
                            B_3();
                            int r;
                            r = sc.nextInt();
                            if (r == 1) {
                                System.out.println("Fill in the details:-\n" +
                                        "1) Set the Opening time for student registrations\n" +
                                        "2) Set the Closing time for student registrations");
                                SimpleDateFormat format = new SimpleDateFormat("dd MMMMMMMMM yyyy, HH:mm");
                                System.out.println("Enter the opening time: ");
                                sc.nextLine();
                                Date d1 = format.parse(sc.nextLine());
                                System.out.println("Enter the closing time: ");
                                Date d2 = format.parse(sc.nextLine());
                                Institute.setOpen_date_for_student(d1);
                                Institute.setClose_date_for_student(d2);
                            } else if (r == 2) {
                                System.out.println("Fill in the details:-\n" +
                                        "1) Set the Opening time for company registrations\n" +
                                        "2) Set the Closing time for company registrations");
                                SimpleDateFormat format = new SimpleDateFormat("dd MMMMMMMMM yyyy, HH:mm");
                                System.out.println("Enter the opening time: ");
                                sc.nextLine();
                                Date d1 = format.parse(sc.nextLine());
                                System.out.println("Enter the closing time: ");
                                Date d2 = format.parse(sc.nextLine());
                                Institute.setOpen_date_for_company_reg(d1);
                                Institute.setClose_date_for_company_reg(d2);
                            } else if (r == 3) {
                                int l1 = Institute.registered_student.size();
                                System.out.println(l1 + " students registered");

                            } else if (r == 4) {
                                int l2 = Institute.registered_company.size();
                                System.out.println(l2 + " companies registered");
                            } else if (r == 5) {

                            } else if (r == 6) {

                            } else if (r == 7) {

                            } else if (r == 8) {

                            } else if (r == 9) {

                            } else if (r == 10) {
                                goBack3 = true;
                            }
                        }
                    } else if (k == 4) {
                        goBack1 = true;
                    }
                }
            } else if (n == 2) {
                exit = true;
                System.out.println("Thanks For Using FutureBuilder!!!!!!");
                System.exit(0);
            }
        }
    }
    static void A_1() {
        System.out.println("Welcome to FutureBuilder:");               //Main application
        System.out.println("   1) Enter the Application");
        System.out.println("   2) Exit the Application");

    }
    static void A_2(){
        System.out.println("Choose The mode you want to Enter in:-");
        System.out.println("  1) Enter as Student Mode");
        System.out.println("  2) Enter as Company Mode");
        System.out.println("  3) Enter as Placement Cell Mode");
        System.out.println("  4) Return To Main Application");

    }
    static void B_1(){
        System.out.println("Choose the Student Query to perform");
        System.out.println("  1) Enter as a Student(Give Student Name, and Roll No.)\n" +
                "2) Add students\n" +
                "3) Back");

    }
    static void B_2() {
        System.out.println("Choose the Company Query to perform-");
        System.out.println("1) Add Company and Details");
        System.out.println("2) Choose Company");
        System.out.println("3) Get Available Companies");
        System.out.println("4) Back");
    }
    static void B_3(){
        System.out.println("Welcome to IIITD Placement Cell");
        System.out.println("  1) Open Student Registrations");
        System.out.println("  2) Open Company Registrations");
        System.out.println("  3) Get Number of Student Registrations");
        System.out.println("  4) Get Number of Company Registrations");
        System.out.println("  5) Get Number of Offered/Unoffered/Blocked Students");
        System.out.println("  6) Get Student Details");
        System.out.println("  7) Get Company Details");
        System.out.println("  8) Get Average Package");
        System.out.println("  9) Get Company Process Results");
        System.out.println("  10) Back");

    }
    static void C_1(){
        System.out.println("1) Register For Placement Drive\n" +
                "2) Register For Company\n" +
                "3) Get All available companies\n" +
                "4) Get Current Status\n" +
                "5) Update CGPA\n" +
                "6) Accept offer\n" +
                "7) Reject offer\n" +
                "8) Back");

    }

}